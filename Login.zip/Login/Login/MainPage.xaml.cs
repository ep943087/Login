﻿using Login.Models;
using Login.Views;
using SQLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Login
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            
            
        }
        async private void Button_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new RegisterPage());
        }

        async private void Button_Clicked_1(object sender, EventArgs e)
        {

            SQLiteConnection db = new SQLiteConnection(App._dbPath);

            User searchUser = db.Table<User>().Where((c)=>
                c.username == username.Text && c.password == password.Text
            ).FirstOrDefault();

            if(searchUser == null)
            {
                await DisplayAlert("ERROR", "Username or password is incorrect", "Try, Again");
            }
            else if(!asAdmin.IsToggled)
            {
                username.Text = password.Text = "";
                await DisplayAlert("SUCCESS", "YOU LOGGED IN SUCCESSFULLY", "OK");
                //await Navigation.PushAsync(new Views.ShowAllUsers(searchUser));
            }
            else if(searchUser.isAdmin)
            {
                username.Text = password.Text = "";
                await DisplayAlert("ADMIN SUCCESS", "YOU LOGGED IN SUCCESSFULLY", "OK");
                await Navigation.PushAsync(new Views.AdminHomePage(searchUser));
            }
            else
            {
                await DisplayAlert("ERROR", "You are not admin", "Try, Again");
            }

            db.Close();
        }
    }
}
